<?php
echo "I am testing";
?>