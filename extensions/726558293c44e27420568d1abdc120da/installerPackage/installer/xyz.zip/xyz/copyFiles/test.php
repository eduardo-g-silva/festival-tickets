<?php
return [
'user'       => ['loginUrl' => ['/users/default/login'],
				 'identityCookie' => [
										'name' => '_backendUser', // unique for backend
									 ]
                ]
				];