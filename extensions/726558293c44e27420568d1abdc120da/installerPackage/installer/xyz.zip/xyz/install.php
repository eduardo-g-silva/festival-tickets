<?php
use usni\UsniAdaptor;
$tablePrefix = UsniAdaptor::tablePrefix();
$data = [
    'name' => 'Test plugin install',
    'author' => 'Mayank Singhai',
    'version' => '1.0',
    'product_version' => ['1.0.0'],
	'category' => 'payment',
	'code'	   => 'test_plugin', 
	'data'	  =>[
					'copyFolders'  => [
										[
											'sourceFolder'   => 'test',
											'targetFolder' => '@common/modules'
										],
										[
											'sourceFolder'   => 'test1',
											'targetFolder' => '@common/components'
										]
									],
					'copyFiles' => [
										[
											'sourceFile' => 'aCopy.txt', 
											'targetFolder' => '@common/modules/test'
										],
										[
											'sourceFile' => 'aModify.txt', 
											'targetFolder' => '@common/modules/test'
										],
										[
											'sourceFile' => 'aDelete.txt', 
											'targetFolder' => '@common/modules/test'
										],
										[
											'sourceFile' => 'aModify.txt', 
											'targetFolder' => '@common/components/test1'
										],
										[
											'sourceFile' => 'aDelete.txt', 
											'targetFolder' => '@common/components/test1'
										],
										[
											'sourceFile' => 'test.php', 
											'targetFolder' => '@common/components/test1'
										]
									],
					'deleteFiles' => [
										['sourceFile' => 'aDelete.txt', 'targetFolder' => '@common/components/test1']
									],
					'modifiedFiles' => [
										['sourceFile' => 'aModify.txt',
										 'targetFolder' => '@common/modules/test',
										 'operations' => [
											 [
												 'type' => 'search',
												 'action' => 'replace',
												 'content' => 'I m testing',
												 'data' => 'I m testing 123',
												 'index'       => '1,3' //Means 1st and 3rd instance only
											 ],
											 [
												 'type' => 'search',
												 'action' => 'add_before',
												 'content' => 'I m testing before123',
												 'data' => 'I m testing 123 Before' . PHP_EOL,
											 ],
											 [
												 'type' => 'search',
												 'action' => 'add_after',
												 'content' => 'I m testing after123',
												 'data' => PHP_EOL . 'I m testing 123 after',
											 ]
										 ] 
										],
										['sourceFile' => 'test.php',
										 'targetFolder' => '@common/components/test1',
										 'operations' => [
											 [
												 'type' => 'search',
												 'action' => 'replace',
												 'content' => "'name' => '_backendUser'",
												 'data' => "'name' => '_backendUser123'",
											 ]
										 ] 
										]
									],
					'sqls'	=> [
									"DROP TABLE IF EXISTS " . $tablePrefix . "test",
									"CREATE TABLE " . $tablePrefix . "test( id INT(11) NOT NULL AUTO_INCREMENT, name VARCHAR(32) NOT NULL, PRIMARY KEY (id) );",
									"INSERT INTO " . $tablePrefix . "test (name) VALUES ('Mayank Singhai')"
								]
			]
];
return $data;